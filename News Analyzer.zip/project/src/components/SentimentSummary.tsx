import React from 'react';
import { BarChart, ThumbsUp, ThumbsDown, Minus } from 'lucide-react';

interface SentimentSummaryProps {
  positive: number;
  negative: number;
  neutral: number;
  total: number;
}

export function SentimentSummary({ positive, negative, neutral, total }: SentimentSummaryProps) {
  const getPercentage = (value: number) => ((value / total) * 100).toFixed(1);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <div className="flex items-center gap-2 mb-4">
        <BarChart className="w-6 h-6 text-blue-500" />
        <h2 className="text-xl font-semibold">Sentiment Analysis Summary</h2>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="flex flex-col items-center p-4 bg-green-50 rounded-lg">
          <ThumbsUp className="w-6 h-6 text-green-500 mb-2" />
          <span className="text-2xl font-bold text-green-600">{getPercentage(positive)}%</span>
          <span className="text-sm text-gray-600">Positive</span>
        </div>
        <div className="flex flex-col items-center p-4 bg-red-50 rounded-lg">
          <ThumbsDown className="w-6 h-6 text-red-500 mb-2" />
          <span className="text-2xl font-bold text-red-600">{getPercentage(negative)}%</span>
          <span className="text-sm text-gray-600">Negative</span>
        </div>
        <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
          <Minus className="w-6 h-6 text-gray-500 mb-2" />
          <span className="text-2xl font-bold text-gray-600">{getPercentage(neutral)}%</span>
          <span className="text-sm text-gray-600">Neutral</span>
        </div>
      </div>
    </div>
  );
}