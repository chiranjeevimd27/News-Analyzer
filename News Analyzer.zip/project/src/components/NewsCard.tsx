import React from 'react';
import { ExternalLink, ThumbsUp, ThumbsDown } from 'lucide-react';
import { NewsArticle } from '../types';

interface NewsCardProps {
  article: NewsArticle;
}

export function NewsCard({ article }: NewsCardProps) {
  const getSentimentColor = () => {
    if (article.sentiment.type === 'positive') return 'text-green-600';
    if (article.sentiment.type === 'negative') return 'text-red-600';
    return 'text-gray-600';
  };

  const getSentimentIcon = () => {
    if (article.sentiment.type === 'positive') return <ThumbsUp className="w-5 h-5" />;
    if (article.sentiment.type === 'negative') return <ThumbsDown className="w-5 h-5" />;
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      {article.urlToImage && (
        <div className="w-full h-48 overflow-hidden">
          <img
            src={article.urlToImage}
            alt={article.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-semibold text-gray-900 flex-1">{article.title}</h3>
          <a
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="ml-4 text-blue-500 hover:text-blue-600"
          >
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
        <p className="text-gray-600 mb-4">{article.description}</p>
        <div className="flex justify-between items-center text-sm">
          <div className="flex items-center gap-2">
            <span className="text-gray-500">
              {new Date(article.publishedAt).toLocaleDateString()}
            </span>
            <span className="text-gray-400">•</span>
            <span className="text-gray-500">{article.source.name}</span>
          </div>
          <div className={`flex items-center gap-2 ${getSentimentColor()}`}>
            {getSentimentIcon()}
            <span className="font-medium capitalize">{article.sentiment.type}</span>
          </div>
        </div>
      </div>
    </div>
  );
}