import React, { useState } from 'react';
import Sentiment from 'sentiment';
import axios from 'axios';
import { Newspaper } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { NewsCard } from './components/NewsCard';
import { SentimentSummary } from './components/SentimentSummary';
import type { NewsArticle, CompanyNews } from './types';

const sentiment = new Sentiment();
const NEWS_API_KEY = '3c85f3c7e88848cca14a5687de82c3bb';

function App() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newsData, setNewsData] = useState<CompanyNews | null>(null);

  const analyzeSentiment = (text: string) => {
    const result = sentiment.analyze(text);
    return {
      score: result.score,
      comparative: result.comparative,
      type: result.score > 0 ? 'positive' : result.score < 0 ? 'negative' : 'neutral',
    };
  };

  const handleSearch = async (company: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get('/api/everything', {
        params: {
          q: company,
          sortBy: 'publishedAt',
          language: 'en',
          pageSize: 10,
          apiKey: NEWS_API_KEY
        }
      });

      if (response.data.status === 'error') {
        throw new Error(response.data.message || 'Failed to fetch news');
      }

      const articles: NewsArticle[] = response.data.articles
        .filter((article: any) => 
          article.title && 
          article.description && 
          !article.title.includes('[Removed]')
        )
        .map((article: any) => ({
          ...article,
          sentiment: analyzeSentiment(article.title + ' ' + article.description),
        }));

      if (articles.length === 0) {
        throw new Error('No news articles found for this company');
      }

      const sentimentSummary = articles.reduce(
        (acc, article) => {
          acc[article.sentiment.type]++;
          return acc;
        },
        { positive: 0, negative: 0, neutral: 0 }
      );

      setNewsData({ articles, sentimentSummary });
    } catch (err: any) {
      console.error('Error fetching news:', err);
      setError(
        err.response?.data?.message || 
        err.message || 
        'Failed to fetch news. Please try again later.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Newspaper className="w-8 h-8 text-blue-500" />
            <h1 className="text-3xl font-bold text-gray-900">News Analyzer</h1>
          </div>
          <p className="text-gray-600 mb-6">
            Enter a company name to analyze recent news sentiment
          </p>
          <SearchBar onSearch={handleSearch} />
        </div>

        {loading && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        {newsData && (
          <div>
            <SentimentSummary
              {...newsData.sentimentSummary}
              total={newsData.articles.length}
            />
            <div className="space-y-6">
              {newsData.articles.map((article, index) => (
                <NewsCard key={index} article={article} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;