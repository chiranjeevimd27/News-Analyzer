export interface NewsArticle {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  publishedAt: string;
  source: {
    name: string;
  };
  sentiment: {
    score: number;
    comparative: number;
    type: 'positive' | 'negative' | 'neutral';
  };
}

export interface CompanyNews {
  articles: NewsArticle[];
  sentimentSummary: {
    positive: number;
    negative: number;
    neutral: number;
  };
}